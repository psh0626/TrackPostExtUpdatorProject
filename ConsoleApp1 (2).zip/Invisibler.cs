﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TrackPostExtUpdator;

internal static class Invisibler
{

  [DllImport("user32.dll")]
  private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  private const int SW_HIDE = 0;
  //private const int SW_SHOW = 5;

  public static void MakeInvisible()
  {
    IntPtr handle = Process.GetCurrentProcess().MainWindowHandle;
    ShowWindow(handle, SW_HIDE);
  }
}
