﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization.Metadata;
using System.Threading.Tasks;

namespace TrackPostExtUpdator;

internal class GithubService
{
  private readonly HttpClient _client;
  private static readonly JsonSerializerOptions options;

  static GithubService()
  {
    options = new JsonSerializerOptions
    {
      PropertyNameCaseInsensitive = true,
      TypeInfoResolver = GitHubJsonContext.Default
    };
  }

  internal GithubService(string userAgent, string token)
  {
    _client = new HttpClient();
    _client.DefaultRequestHeaders.UserAgent.ParseAdd(userAgent);
    _client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
  }

  public async Task<List<string>> GetRepositoriesAsync(string username)
  {
    var response = await _client.GetAsync($"https://api.github.com/users/{username}/repos");
    response.EnsureSuccessStatusCode();
    var content = await response.Content.ReadAsStringAsync();
    var repositories = JsonSerializer.Deserialize(content, GitHubJsonContext.Default.ListRepository);
    if (repositories == null)
      return [];
    return repositories.Select(repo => repo.Name).ToList();
  }

  // Equivalent to Octokit's UserClient.Get()
  public async Task<User?> GetUserAsync(string username)
  {
    var response = await _client.GetAsync($"https://api.github.com/users/{username}");
    response.EnsureSuccessStatusCode();
    var content = await response.Content.ReadAsStringAsync();
    var user = JsonSerializer.Deserialize(content, GitHubJsonContext.Default.User);

    return user;
  }
}

[JsonSerializable(typeof(List<Repository>))]
[JsonSerializable(typeof(User))]
internal partial class GitHubJsonContext : JsonSerializerContext
{
}

public class Repository
{
  public required string Name { get; set; }
}

public class User
{
  public required string Login { get; set; }
  public int Id { get; set; }
  public required string AvatarUrl { get; set; }
}