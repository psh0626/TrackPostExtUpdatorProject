﻿// See https://aka.ms/new-console-template for more information
using System.IO.Compression;
using System.Net.Http;
using System.Text.Json;
using System.IO;
using Octokit;
using System.IO.Pipes;
using System;
using System.Diagnostics;
using TrackPostExtUpdator;
using System.Data;
using System.Reflection;
using System.Runtime.InteropServices;

const string USER_AGENT = "TrackPostUpdater";
const string TOKEN = "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";

try
{
  Console.BackgroundColor = ConsoleColor.White;
  Console.ForegroundColor = ConsoleColor.Black;
  Console.Clear();
  var githubClient = Updator.BuildGithubClient(USER_AGENT, TOKEN);

  if (args.Length == 3)
  {
    switch (args[0])
    {
      case "--updator":
        var local_pid = int.Parse(args[1]);
        var local_path = args[2];
        var temp_path = Environment.ProcessPath!;
        await Updator.OverwriteAndWait(local_pid, temp_path, local_path);
        break;
      case "--updated":
        var temp_pid = int.Parse(args[1]);
        var temp_file_path = args[2];
        await Updator.DisposeTempFile(temp_pid, temp_file_path);
        break;
    }
  }
  else
  {
    await Updator.UpdateUpdator(githubClient);
  }

  var currnet_directory = Path.GetDirectoryName(Environment.ProcessPath);
  Directory.SetCurrentDirectory(currnet_directory!);

  await Updator.UpdateTrackPost(githubClient);

  //Console.ReadKey(true);
}
catch (Exception e)
{
  if (args.Length > 0 && args[0] == "--updator")
    Environment.Exit(1);

  for(var i=0; i<10; i++)
  {
    Console.WriteLine("");
  }
  Console.WriteLine("에러 발생: 박성훈을 불러주세요.\n\n");
  Console.WriteLine(e);
  Console.ReadLine();
}
